#!/usr/bin/python3
import random
import subprocess
import time
from pybloom_live import BloomFilter

puzzle = 71
address = "1PWo3JeB9jrGwfHDNpdGK54CRas7fsVzXU"

GPUI = "0,1"
GPUX = "512,256,512,256"
LOWER = 2 ** (puzzle - 1)
UPPER = (2 ** puzzle) - 1
BIT_GAP = 2 ** 40

bloom = BloomFilter(capacity=10_000_000, error_rate=1e-6)

def found_real_match(output: str) -> bool:
    for line in output.splitlines():
        if "[F:" in line:
            try:
                f = int(line.split("[F:")[1].split("]")[0])
                return f > 0
            except:
                pass
    return False

count = 0

while True:
    count += 1

    prefix = hex(random.randint(4, 7))[2:]

    first = random.randrange(LOWER, UPPER - BIT_GAP)
    second = min(first + BIT_GAP, UPPER)

    first_hex = prefix + f"{first:X}"[1:]
    second_hex = prefix + f"{second:X}"[1:]

    key_range = f"{first_hex}:{second_hex}"

    if key_range in bloom:
        continue
    bloom.add(key_range)

    cmd = [
        "./Rotor",
        "-g",
        "--gpui", GPUI,
        "--gpux", GPUX,
        "-m", "address",
        "--coin", "BTC",
        "--range", key_range,
        address
    ]

    print(f"\n[{count}] Range: {key_range}")

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    stdout, stderr = proc.communicate()
    print(stdout)

    if found_real_match(stdout):
        with open("found_match.txt", "w") as f:
            f.write(stdout)
        print("\n🔥🔥 CHAVE REALMENTE ENCONTRADA 🔥🔥")
        break

    print("Range finalizado — nenhum match real. Continuando...\n")
    time.sleep(0.1)